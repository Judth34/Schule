/*
 * @(#)SynchStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A synchronized statement. JLS3 14.19.
 *
 * @author Andy Yu
 * */
public interface SynchStatementT
  extends CompoundStatementT
{
  // ----------------------------------------------------------------------
}
