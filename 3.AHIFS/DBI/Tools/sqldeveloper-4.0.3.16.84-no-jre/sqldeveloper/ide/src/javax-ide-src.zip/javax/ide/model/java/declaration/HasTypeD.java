/*
 * @(#)HasTypeD.java
 */

package javax.ide.model.java.declaration;

/**
 * Common supertype for Declaration elements that have a type.
 *
 * @author Andy Yu
 */
public interface HasTypeD
  extends Declaration
{
  /**
   * Gets the type of this element.
   *
   * @return The type of this element.
   */
  public TypeD getType();
}
