/*
 * @(#)BlockElementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * Common supertype for elements that may be a child of a code
 * block. <p/>
 *
 * @author Andy Yu
 */
public interface BlockElementT
  extends Tree
{
  // ----------------------------------------------------------------------
  
  public static BlockElementT[] EMPTY_ARRAY = new BlockElementT[ 0 ];
}
