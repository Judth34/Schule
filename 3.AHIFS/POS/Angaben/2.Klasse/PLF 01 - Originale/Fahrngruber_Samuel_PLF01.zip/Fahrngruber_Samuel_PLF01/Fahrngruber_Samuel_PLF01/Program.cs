﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrngruber_Samuel_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            Umsaetze UmsaetzeDiesesJahres = new Umsaetze();



            UmsaetzeDiesesJahres.AnzahlVerkaeufer = getValidNumber(1, 10, "Wie Viele Verkäufer soll es geben");
            UmsaetzeDiesesJahres.BelegeWerte();

            double Durchschnitt;
            int VerkaeuferIdx;

            Durchschnitt = UmsaetzeDiesesJahres.GetMonatsdurchschnittAllerVerkaeufer();
            Console.WriteLine("Der Durchschnittsumsatz aller Verkaeufer pro Monat ist: " + Durchschnitt);

            Durchschnitt = UmsaetzeDiesesJahres.GetJahresdurchschnittAllerVerkaeufer();
            Console.WriteLine("Der Durchschnittsumsatz aller Verkaeufer pro Jahr ist: " + Durchschnitt);

            VerkaeuferIdx = getValidNumber(1, UmsaetzeDiesesJahres.AnzahlVerkaeufer, "Geben Sie die Verkäufer-Nummer ein für die Berechnung des Monatsumsatzes dieses Verkäufers") - 1;
            UmsaetzeDiesesJahres.GetDurchschnittProVerkaeufer(VerkaeuferIdx, out Durchschnitt);
            Console.WriteLine("Der Durchschnittsumsatz aller Verkaeufer pro Monat ist: " + Durchschnitt);

        }
        static int getValidNumber(int Untergrenze, int Obergrenze, string Message)
        {
            int returnValue;
            bool boolean;
            do
            {
                Console.Write(Message + " [" + Untergrenze + ", " + Obergrenze + "] : ");
                boolean = int.TryParse(Console.ReadLine(), out returnValue);
                Console.WriteLine();
            } while ((boolean == false) || (returnValue < Untergrenze) || (returnValue > Obergrenze));
            return returnValue;
        }
    }
}
