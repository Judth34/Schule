﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrngruber_Samuel_PLF01
{
    class Umsaetze
    {
        private int anzahlVerkaeufer;
        private int anzahlUmsaetze;

        private short[,] umsaetze;

        public int AnzahlVerkaeufer
        {
            get
            {
                return anzahlVerkaeufer;
            }
            set
            {
                if(value > 0)
                {
                    anzahlVerkaeufer = value;
                    umsaetze = new short[anzahlVerkaeufer, anzahlUmsaetze];
                }
            }
        }

        public Umsaetze()
        {
            anzahlUmsaetze = 12;
            anzahlVerkaeufer = 1;
        }
        
        public void BelegeWerte()
        {
            for (int VerkaeuferIdx = 0; VerkaeuferIdx < anzahlVerkaeufer; VerkaeuferIdx++)
            {
                for (int MonatsIdx = 0; MonatsIdx < anzahlUmsaetze; MonatsIdx++)
                {
                    umsaetze[VerkaeuferIdx, MonatsIdx] = (short)(((VerkaeuferIdx + 1) * 100) + (MonatsIdx * 10));
                }
            }
        }
        public bool GetDurchschnittProMonat(int Monat, out double Durchschnitt)
        {
            bool result;
            if (Monat >= 0 && Monat < anzahlUmsaetze)
            {
                result = true;
                int summe = 0;
                for (int VerkaeuferIdx = 0; VerkaeuferIdx < anzahlVerkaeufer; VerkaeuferIdx++)
                {
                    summe += umsaetze[VerkaeuferIdx, Monat];
                }
                Durchschnitt = (double)summe / anzahlVerkaeufer;
            }
            else
            {
                result = false;
                Durchschnitt = 0.0;
            }
            return result;
        }
        public bool GetDurchschnittProVerkaeufer(int Verkaeufer, out double Durchschnitt)
        {
            bool result;
            if(Verkaeufer >= 0 && Verkaeufer < anzahlVerkaeufer)
            {
                result = true;
                int summe = 0;
                for(int MonatsIdx = 0; MonatsIdx < anzahlUmsaetze; MonatsIdx++)
                {
                    summe += umsaetze[Verkaeufer, MonatsIdx];
                }
                Durchschnitt = (double)summe / anzahlUmsaetze;
            }
            else
            {
                result = false;
                Durchschnitt = 0.0;
            }
            return result;
        }
        public double GetMonatsdurchschnittAllerVerkaeufer()
        {
            double Durchschnitt;

            Durchschnitt = GetJahresdurchschnittAllerVerkaeufer() / anzahlUmsaetze;

            return Durchschnitt;
        }
        public double GetJahresdurchschnittAllerVerkaeufer()
        {
            double Durchschnitt = 0.0;
            for (int MonatsIdx = 0; MonatsIdx < anzahlUmsaetze; MonatsIdx++)
            {
                double monatsdurchschnitt;
                GetDurchschnittProMonat(MonatsIdx, out monatsdurchschnitt);
                Durchschnitt += monatsdurchschnitt;
            }
            return Durchschnitt;
        }
    }
}
