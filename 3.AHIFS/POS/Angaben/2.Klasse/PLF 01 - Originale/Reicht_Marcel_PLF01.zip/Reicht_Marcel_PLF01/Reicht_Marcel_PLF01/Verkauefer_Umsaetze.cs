﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reicht_Marcel_PLF01
{
    class Verkauefer_Umsaetze
    {
        public int AnzahlVerkauefer;

        private void UmsatzProVerkaeufer(double[,] Umsaetze)
        {
            int AnzahlVerkaeufer = 1;
            int AnzahlMonate = 12;

            for (int VerkaeuferIDX = 0; VerkaeuferIDX < AnzahlMonate; VerkaeuferIDX++)
            {
                for (int MonatIDX = 0; MonatIDX < AnzahlVerkaeufer; MonatIDX++)
                {
                    Umsaetze[VerkaeuferIDX, MonatIDX] = 100;
                }
            }
        }

        public double DurchschnittsumsatzVerkaeufer(AnzahlVerkauefer, double[,] Umsaetze)
        {

        }
    }
}
