﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reicht_Marcel_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            int AnzahlVerkaeufer;
            string Eingabe;

            Console.Write("Wie viele Verkaeufer soll es geben: ");
            Eingabe = Console.ReadLine();
            AnzahlVerkaeufer = int.Parse(Eingabe);
            
        }
    }
}

