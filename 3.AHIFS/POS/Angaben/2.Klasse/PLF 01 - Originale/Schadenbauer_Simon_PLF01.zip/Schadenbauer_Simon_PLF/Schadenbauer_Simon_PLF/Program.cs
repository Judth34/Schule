﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schadenbauer_Simon_PLF
{
    class Program
    {
        static void Main(string[] args)
        {
            Umsatz u1 = new Umsatz();
            int verkaeuferMax = 0;
            int verkaeuferidx = 0;
            double verkaeuferSchnitt = 0;
            double monatsschnitt = 0;
            double jahresSchnitt = 0;

            verkaeuferMax = getValidNumber(1, 10, "Wie viele Verkaeufer soll es geben: ");
            u1.Verkaeuferanzahl = verkaeuferMax;

            jahresSchnitt = u1.JahresUmsatzschnittBerechnen();
            Console.WriteLine("Der Durchschnitt aller Verkaeufer pro Jahr ist " + jahresSchnitt);
            monatsschnitt = u1.MonatsUmsatzschnittBerechnen();
            Console.WriteLine("Der Durchschnitt aller Verkaeufers dieses Monats ist " + monatsschnitt);
            verkaeuferidx = getValidNumber(1, verkaeuferMax, "Geben Sie die Verkaeufernummer ein für die Berechnung des Monatsumsatzes: ");
            verkaeuferSchnitt = u1.VerkaeuferUmsatzschnittBerechnen(verkaeuferidx);
            Console.WriteLine("Der Durchschnitt dieses Verkaeufers pro Jahr ist " + verkaeuferSchnitt);
        }
        static int getValidNumber(int ug, int og, string message)
        {
            int eingabe = 0;
            bool erg;

            do
            {
                Console.Write(message);
                erg = int.TryParse(Console.ReadLine(), out eingabe);
            } while (erg == false || eingabe < ug || eingabe > og);

            return eingabe;
        }
    }
}
