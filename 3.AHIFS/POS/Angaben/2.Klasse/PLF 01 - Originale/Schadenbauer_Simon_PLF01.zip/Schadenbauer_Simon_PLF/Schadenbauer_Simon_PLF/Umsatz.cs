﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schadenbauer_Simon_PLF
{
    class Umsatz
    {
        private int verkaeuferanzahl = 0;
        private int MonatMax = 0;
        private int[,] verkaeuferumsatz;
        public Umsatz()
        {
            verkaeuferanzahl = 1;
            MonatMax = 12;
            verkaeuferumsatz = new int[verkaeuferanzahl, MonatMax];
            FillArray();
        }
        #region properties
        public int Verkaeuferanzahl
        {
            get { return verkaeuferanzahl; }
            set
            {
                if (value > 0)
                {
                    verkaeuferanzahl = value;
                    verkaeuferumsatz = new int[verkaeuferanzahl, MonatMax];
                    FillArray();
                }
            }
        }
        #endregion
        private void FillArray()
        {
            int wert = 100; // array wird mit gegebenen Werten gefüllt
            for(int verkaeuferidx = 0; verkaeuferidx < verkaeuferanzahl; verkaeuferidx++)
            {
                for(int umsatzidx = 0; umsatzidx < 12; umsatzidx++)
                {                    
                    verkaeuferumsatz[verkaeuferidx, umsatzidx] = wert;
                    wert += 10;
                }
                wert -= 20;
            }
        }

        public double MonatsUmsatzschnittBerechnen()
        {
            int anzahl = 0;
            double ergMonat = 0;

            for (int idxVerkaeufer = 0; idxVerkaeufer < verkaeuferanzahl; idxVerkaeufer++)
            {
                for (int idxMonat = 0; idxMonat < MonatMax; idxMonat++)
                {
                    ergMonat += verkaeuferumsatz[idxVerkaeufer, idxMonat];
                }
            }

            anzahl = verkaeuferumsatz.Length;
            ergMonat /= anzahl;

            return ergMonat;
        }
        public double VerkaeuferUmsatzschnittBerechnen(int Verkaeufer)
        {
            double ergVerkaeufer = -1;

            if (Verkaeufer > 0 && Verkaeufer <= verkaeuferanzahl)
            {
                ergVerkaeufer = 0;
                for (int monatsidx = 0; monatsidx < MonatMax; monatsidx++)
                {
                    ergVerkaeufer += verkaeuferumsatz[(Verkaeufer - 1), monatsidx];
                }

                ergVerkaeufer /= MonatMax;
            }

            return ergVerkaeufer;
        }
        public double JahresUmsatzschnittBerechnen()
        {
           double ergJahr = 0;
            for (int monatidx = 0; monatidx < MonatMax; monatidx++)
            {
                for (int schueleridx = 0; schueleridx < verkaeuferanzahl; schueleridx++)
                {
                    ergJahr += verkaeuferumsatz[schueleridx, monatidx];
                }
            }
                ergJahr /= verkaeuferanzahl;

            return ergJahr;
        }

    }
}
