﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mühlbacher_Paul_PLF01
{
    class Umsatz
    {
        private int anzahlVerkaeufer;
        private int monate;
        private int[,] alleVerkaeufe;

        public Umsatz()
        {
            anzahlVerkaeufer = 1;
            monate = 12;
            alleVerkaeufe = new int[anzahlVerkaeufer, monate];
        }

        public int AnzahlVerkaeufer
        {
            get { return anzahlVerkaeufer; }
            set
            {
                if(value > 1)
                {
                    anzahlVerkaeufer = value;
                    alleVerkaeufe = new int[anzahlVerkaeufer, monate];
                }
            }
        }

        public void GetTestData()
        {
            int betrag = 100;
            
            for(int idxVerkaeufer = 0; idxVerkaeufer < anzahlVerkaeufer; idxVerkaeufer++)
            {
                for(int idxMonate = 0; idxMonate < monate; idxMonate++)
                {
                    SaveData(idxVerkaeufer, idxMonate, betrag);
                    betrag = betrag + 10;                    
                }

                betrag = betrag - 20;
            }
        }

        public int SaveData(int idxVerkaeufer, int idxMonat, int betrag)
        {
            int result = 0;

            if(betrag < 0)
            {
                result = result + 1;
            }

            result = result + CheckData(idxVerkaeufer, idxMonat);

            if(result == 0)
            {
                alleVerkaeufe[idxVerkaeufer, idxMonat] = betrag; 
            }
            return result;
        }

        private int CheckData(int idxVerkaeufer, int idxMonat)
        {
            int result = 0;

            if (idxVerkaeufer < 1 || idxVerkaeufer > anzahlVerkaeufer)
            {
                result = result + 10;
            }

            if (idxMonat < 1 || idxMonat > 12)
            {
                result = result + 100;
            }
            return result;
        }

        public double DurchschnittAllerVerkaeuferProMonat()
        {
            int summe = 0;
            double durchschnitt = 0;

             for (int idxMonat = 0; idxMonat < monate; idxMonat++)
             {
                 for (int idxVerkaefer = 0; idxVerkaefer < anzahlVerkaeufer; idxVerkaefer++)
                 {
                    summe = summe + alleVerkaeufe[idxVerkaefer, idxMonat];
                    
                 }

                durchschnitt = durchschnitt + (double)summe / anzahlVerkaeufer;
            }

            return durchschnitt / monate;
        }

        public double DurchschnittUmsatzVerkaeuferProJahr()
        {
            int summe = 0;

            for(int idxVerkaeufer = 0; idxVerkaeufer < anzahlVerkaeufer; idxVerkaeufer++)
            {
                for(int idxMonat = 0; idxMonat < monate; idxMonat++)
                {
                    summe = summe + alleVerkaeufe[idxVerkaeufer, idxMonat];
                }
            }
            Console.WriteLine(summe);
            return (double)summe / alleVerkaeufe.Length;
        }

        public int DurchschnittEinesVerkaeufersProMonat(int verkaeufer, out double erg)
        {
            int summe = 0;
            int result = 0;

            result = result + CheckData(verkaeufer, 1);
             
            if(result == 0)
            {
                for(int idxMonat = 0; idxMonat < monate; idxMonat++)
                {
                    summe = summe + alleVerkaeufe[verkaeufer, idxMonat];
                }

                erg = (double)summe / monate;
            }

            else
            {
                erg = 0;
            }

            return result;
        }
    }
}
