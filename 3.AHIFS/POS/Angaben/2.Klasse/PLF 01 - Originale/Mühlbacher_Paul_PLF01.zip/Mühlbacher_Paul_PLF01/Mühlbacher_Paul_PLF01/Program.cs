﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mühlbacher_Paul_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            Umsatz firstMatrix = new Umsatz();
            int anzahlVerkaeufer = 0;
            int result = 0;
            double erg = 0;
            int verkaeufer = 0;

            anzahlVerkaeufer = getValidNumber(1, 5, "Gib die Anzahl der Verkäufer ein (1-5): ");
            firstMatrix.AnzahlVerkaeufer = anzahlVerkaeufer;

            firstMatrix.GetTestData();

            Console.WriteLine("Der Durchschnittsumsatz aller Verkäufer pro Monat ist: "+ firstMatrix.DurchschnittAllerVerkaeuferProMonat());
            Console.WriteLine("Der Durchschnittsumsatz aller Verkaüfer pro Jahr is: " + firstMatrix.DurchschnittUmsatzVerkaeuferProJahr());

            verkaeufer = getValidNumber(1, anzahlVerkaeufer, "Geben Sie die Verkäufer Nummer ein für die Berechnung des Monatsumsatzes dieses Verkäufers: ");
            result = firstMatrix.DurchschnittEinesVerkaeufersProMonat(verkaeufer, out erg);
            Console.WriteLine("Der Durchschnittsumsatzes dieses Verkäufers pro Monat ist: " + erg);
            
        }

        static int getValidNumber(int untergrenze, int obergrenze, string text) //Funktion die die Eingabe einliest und prüft
        {
            int eingabe;
            bool erg;

            do
            {
                Console.Write(text);
                erg = int.TryParse(Console.ReadLine(), out eingabe);
            } while ((erg == false) || ((eingabe < untergrenze) || (eingabe > obergrenze)));

            return eingabe;
        }
    }
}
