﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Berisa_Valon_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            int monate = 12;
            int bestimmterVerkaeufer;
            int min = 1;
            int max = 10;

            UmsatzVerwaltung Verkaufers = new UmsatzVerwaltung();
            Console.Write("Wie viele Verkaeufer soll es geben: ");
            Verkaufers.NumberOfVerkaeufer = int.Parse(Console.ReadLine());
            
            Verkaufers.filllArray();
            AveragOfYear(Verkaufers,monate);
            print2dArray(Verkaufers);

            Console.Write("Geben Sie die Verkaeufer Nummer ein für die Berechnung des Monatsumsatzes dieses Verkaeufers: ");
            bestimmterVerkaeufer = EingabeUeberpruefung(min, max);
            Console.WriteLine("Der Durchschnittsumsatz dieses Verkaeufers pro Monat ist : " + Verkaufers.AverageMonthOfVerkaufer(bestimmterVerkaeufer));

            Console.WriteLine("Der Durschnittsumsatz aller Verkaeufer pro Monat ist: " + Verkaufers.TotalAverage());


        }


        static public void AveragOfYear(UmsatzVerwaltung Verkaufers, int monate)
        {
            for (int numberOfVerkaufer = 0; numberOfVerkaufer < Verkaufers.NumberOfVerkaeufer; numberOfVerkaufer++)
            {
                Console.Write("Nr." + (numberOfVerkaufer + 1) + "  ");
                for (int monat = 0; monat < monate; monat++)
                {

                    Console.Write(Verkaufers.MarkPrinter(numberOfVerkaufer, monat) + "    ");
                }

                Console.WriteLine();
            }
        }

        static public void print2dArray(UmsatzVerwaltung Verkaufers)
        {
            int Umsatz = 0;
            for (int verkaufer = 0; verkaufer < Verkaufers.NumberOfVerkaeufer; verkaufer++)
            {
                Umsatz = Umsatz + Verkaufers.UmstatzPerMonth(verkaufer);
            }
            Console.WriteLine("\nDurchschnitt aller Verkaufer pro Jahr ist: " + Umsatz / Verkaufers.NumberOfVerkaeufer);
        }

        static int EingabeUeberpruefung(int min, int max)
        {
            int zahl;
            bool zahlGueltig;

            do
            {
                
                zahlGueltig = int.TryParse(Console.ReadLine(), out zahl);
            } while (!zahlGueltig || (zahl > max || zahl < min));

            return zahl;
        }
    }
}
