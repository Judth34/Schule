﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Berisa_Valon_PLF01
{
    class UmsatzVerwaltung
    {
        #region members
        int numberOfVerkaeufer;
        int[,] AllUmsatz;
        #endregion

        #region properties
        public int NumberOfVerkaeufer
        {
            get { return numberOfVerkaeufer; }
            set
            {
                if (value > 0)
                {
                    numberOfVerkaeufer = value;
                    AllUmsatz = new int[numberOfVerkaeufer, 12];

                }
            }
        }
        #endregion
        
        #region public methods

        public void filllArray()
        {
            int Umsatz = 100;

            for (int Verkaufer = 0; Verkaufer < numberOfVerkaeufer; Verkaufer++)
            {
                for (int monat = 0; monat < 12; monat++)
                {
                    AllUmsatz[Verkaufer, monat] = Umsatz;
                    Umsatz = Umsatz + 10;
                }
                Umsatz = Umsatz - 20;
                
                Console.WriteLine();
            }
        }

        public int UmstatzPerMonth(int verkaufer)
        {
            int AverageOfVerkaufer = 0;

            for(int monat = 0; monat < 12; monat++)
            {
                AverageOfVerkaufer += AllUmsatz[verkaufer, monat];
            }

            return AverageOfVerkaufer;
        }

        public int AverageMonthOfVerkaufer(int verkaufer)
        {
            int average = 0;
            int monate = 12;
            for(int monat = 0; monat < monate; monat++)
            {
                average += AllUmsatz[verkaufer, monat];
            }
            
            return average / monate;
        }


        public int TotalAverage()
        {
            int average = 0;
            int monate = 12;
            for (int verkaufer = 0; verkaufer < numberOfVerkaeufer; verkaufer++)
            {
                for (int monat = 0; monat < monate; monat++)
                {
                    average += AllUmsatz[verkaufer, monat];
                }
            }

            return average / (numberOfVerkaeufer * monate);
        }

        public int MarkPrinter(int numberOfVerkaeufer, int monate)
        {
            return AllUmsatz[numberOfVerkaeufer, monate];
        }

        #endregion
    }

}

