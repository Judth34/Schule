﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hebein_Fabian_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {

            int AnzahlVerkaeufer, minAnzahlVerkaeufer = 1, maxAnzahlVerkaeufer = 10000;
            int VerkaeuferAuswahl;

            AnzahlVerkaeufer= GetValidNumber(minAnzahlVerkaeufer, maxAnzahlVerkaeufer, "Geben Sie die Anzahl der Verkäufer ein (min. " + minAnzahlVerkaeufer + " ): ");
            UmsatzVerkaeufe Jahr1 = new UmsatzVerkaeufe(AnzahlVerkaeufer);

            Console.WriteLine("Der Durchschnittsumsatz aller Verkäufer pro Monat ist: " + Jahr1.MonatsDurchschnitt());
            Console.WriteLine("Der Durchschnittsumsatz aller Verkäufer pro Jahr ist: " + Jahr1.SummeMonatsDurchschnitte());

            VerkaeuferAuswahl = GetValidNumber(minAnzahlVerkaeufer, Jahr1.VerkaeuferAnzahl, "Geben Sie die Verkäufer Nummer ein für die Berechnung des Jahresumsatzes dieses Verkäufers: ");
            Console.WriteLine("Der Durchschnittsumsatz dieses Verkäufers pro Jahr ist: " + Jahr1.JahresDurchschnittVerkaeufer(VerkaeuferAuswahl));

        }

        static int GetValidNumber(int min, int max, string msg)
        {
            int zahl;
            bool zahlGueltig;

            do
            {
                Console.Write(msg);
                zahlGueltig = int.TryParse(Console.ReadLine(), out zahl);
            } while (!zahlGueltig || (zahl > max || zahl < min));

            return zahl;
        }
    }
}
