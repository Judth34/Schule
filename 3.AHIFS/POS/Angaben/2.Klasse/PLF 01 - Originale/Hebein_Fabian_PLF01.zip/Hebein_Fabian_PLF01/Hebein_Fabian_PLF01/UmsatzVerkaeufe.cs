﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hebein_Fabian_PLF01
{
    class UmsatzVerkaeufe
    {
        #region

        private int anzahlMonate = 12;
        private int anzahlVerkaeufer;
        private int[,] Umsaetze;

        #endregion

        #region Konstruktor(en)

        public UmsatzVerkaeufe(int Verkaeufer)
        {
            anzahlVerkaeufer = 5;
            VerkaeuferAnzahl = Verkaeufer;
            Umsaetze = new int[VerkaeuferAnzahl, anzahlMonate];

            for(int VerkaeuferIdx = 0; VerkaeuferIdx < VerkaeuferAnzahl; VerkaeuferIdx++)
            {

                for (int MonatsIdx = 0; MonatsIdx < anzahlMonate; MonatsIdx++)
                {
                    Umsaetze[VerkaeuferIdx, MonatsIdx] += (VerkaeuferIdx + 1) * 100 + MonatsIdx * 10;
                }
            }

        }

        #endregion

        #region properties
        public int VerkaeuferAnzahl
        {

            get
            {
                return anzahlVerkaeufer;
            }
            set
            {
                if(value > 0)
                {
                    anzahlVerkaeufer = value;
                }
            }
        }
        #endregion

        #region Public

        public double MonatsDurchschnitt()
        {
            int Summe = 0;

            for (int VerkaeuferIdx = 0; VerkaeuferIdx < Umsaetze.GetLength(0); VerkaeuferIdx++)
            {

                for (int MonatsIdx = 0; MonatsIdx < Umsaetze.GetLength(1); MonatsIdx++)
                {
                    Summe += Umsaetze[VerkaeuferIdx, MonatsIdx];
                }
            }
            return Summe / (anzahlMonate * VerkaeuferAnzahl);
        }

        public double SummeMonatsDurchschnitte()
        {
            return MonatsDurchschnitt() * anzahlMonate;
        }

        public double JahresDurchschnittVerkaeufer(int VerkaeuferNummer)
        {
            int Summe = 0;
            VerkaeuferNummer--;

            for (int MonatsIdx = 0; MonatsIdx < anzahlMonate; MonatsIdx++)
            {
                Summe += Umsaetze[VerkaeuferNummer, MonatsIdx];

            }
            return Summe / anzahlMonate;
        }


        #endregion

    }
}
