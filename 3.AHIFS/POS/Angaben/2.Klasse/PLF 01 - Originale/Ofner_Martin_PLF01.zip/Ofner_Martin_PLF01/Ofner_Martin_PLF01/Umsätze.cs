﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ofner_Martin_PLF01
{
    class Umsätze
    {
        private int anzahlVerkäufer = 5;
        private double[,] Einnahmen = new double[5, 12];
        public Umsätze()
        {
            Einnahmen = new double[anzahlVerkäufer, 12];
            EinnahmenEinlesen();
        }
        #region Properties
        public int AnzahlVerkäufer
        {
            get { return anzahlVerkäufer; }
            set
            {
                if (value > 0 && value < 10)
                {
                    anzahlVerkäufer = value;
                    Einnahmen = new double[anzahlVerkäufer, 12];
                    EinnahmenEinlesen();
                }
            }
        }
        #endregion
        private void EinnahmenEinlesen()
        {
            int wert = 100;
            for (int VerkäuferIDX = 0; VerkäuferIDX < anzahlVerkäufer; VerkäuferIDX++)
            {
                wert = 100 + VerkäuferIDX * 100;
                for (int MonatsIDX = 0; MonatsIDX < 12; MonatsIDX++)
                {
                    Einnahmen[VerkäuferIDX, MonatsIDX] = wert;
                    wert = wert+10;
                }
            }
        }
        public double DurchschnittsUmsatzAllerproMonat()
        {
            
            double durschnitt = 0;
            double summe = 0;
            
           
                for (int VerkäuferIDX = 0; VerkäuferIDX < anzahlVerkäufer; VerkäuferIDX++)
                {
                for (int Monatsidx = 0; Monatsidx < 12; Monatsidx++)
                {
                    summe = summe + Einnahmen[VerkäuferIDX, Monatsidx];
                    
                }
                durschnitt += summe / 12;
            }
               
            
            return durschnitt;
        }
        public double DurchschnittAlleVerkäuferEinesMonats(int BeliebigerMonat)
        {
            double durchschnitt = 0;
            double summe = 0;
            int verkäuferIDX = 0;
            for (; verkäuferIDX < anzahlVerkäufer; verkäuferIDX++)
            {
                summe += Einnahmen[verkäuferIDX, BeliebigerMonat];
            }
            durchschnitt = summe / verkäuferIDX;
                
            return durchschnitt;
        }
        private double SummeEinesVerkäufersProjahr(int verkäufer)
        {
            double durchschnitt = 0;
            double summe = 0;
                for(int MonatsIDX = 0; MonatsIDX < 12; MonatsIDX++)
            {
                summe=summe+ Einnahmen[verkäufer, MonatsIDX];
            }
            durchschnitt = summe / 12;
            return durchschnitt;
        }
        public double DurchschnittAllerVerkäuferProJahr()
        {
            double durchschnitt = 0;
            double summe = 0;
            for (int VerkäuferIDX = 0; VerkäuferIDX < anzahlVerkäufer; VerkäuferIDX++)
            {
                for (int MonatsIDX = 0; MonatsIDX < 12; MonatsIDX++)
                {
                    summe = summe + SummeEinesVerkäufersProjahr(VerkäuferIDX);
                }
               
            }
            durchschnitt = summe / 5;
            return durchschnitt;
        }
     public double DurchschnittEinesverkäufersProJahr(int Verkäufer)
        {
            double durchschnitt = 0;
            double summe = 0;
                for(int monatsidx = 0; monatsidx < 12; monatsidx++)
            {
                summe+= Einnahmen[Verkäufer, monatsidx];
            }
            durchschnitt = summe / 12;
            return durchschnitt;
        }
       
       

    }
}
