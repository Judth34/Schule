﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ofner_Martin_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            Umsätze Verkäufer = new Umsätze();
           

            //Console.WriteLine(Verkäufer.DurchschnittsUmsatzAllerproMonat(getValidNumber(1,12,"Für Welchen Monat willst du denn Durchschnitt Aller berechnen?:")));
            Console.WriteLine("Der Durchschnitt aller verkäufer pro jahr ="+ Verkäufer.DurchschnittAllerVerkäuferProJahr());
            Console.WriteLine("Der durchschnitt eines verkäufers(3) pro jahr ="+Verkäufer.DurchschnittEinesverkäufersProJahr(3));
            Console.WriteLine("Der Durchschnitt aller verkäufer des 3.monats=" + Verkäufer.DurchschnittAlleVerkäuferEinesMonats(3));
            Console.WriteLine("Der Durchschnitt aller verkäufer pro monat=" + Verkäufer.DurchschnittsUmsatzAllerproMonat());
        }
        static int getValidNumber(int untergrenze, int obergrenze, string text) //Funktion die die Eingabe einliest und prüft
        {
            int eingabe;
            bool erg;

            do
            {
                do
                {
                    Console.Write(text);
                    erg = int.TryParse(Console.ReadLine(), out eingabe);
                } while (erg == false);
            }
            while ((eingabe < untergrenze) || (eingabe > obergrenze));

            return eingabe;
        }
    }
}
