﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kraschl_Christof_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            UmsatzVerwaltung umsatzMatrix = new UmsatzVerwaltung();
            int average = 0;
            int verkaeuferIdx = 0;

            umsatzMatrix.NumberOfVerkaeufer = getValidNumber(1, 100, "Wie viele Verkäufer soll es geben: ");

            average = umsatzMatrix.averageAllVerkaeuferMonth();
            Console.WriteLine("Durchschnitt aller Verkäufer pro Monat: " + average);

            average = umsatzMatrix.averageAllVerkaeuferYear();
            Console.WriteLine("Der Durchschnittumsatz dieses Verkäufers pro Jahr ist: " + average);

            verkaeuferIdx = getValidNumber(1, umsatzMatrix.NumberOfVerkaeufer, "Gib die Nummer des gewünschten Verkäufers ein: ");
            average = umsatzMatrix.averageVerkaeuferYear(verkaeuferIdx - 1);
            Console.WriteLine("Der Durchschnittumsatz dieses Verkäufers pro Monat ist: " + average);
        }

        static int getValidNumber(int validMin, int validMax, string userText)
        {
            bool erg;
            int varNumber = 0;
            do
            {
                Console.Write(userText);
                erg = int.TryParse(Console.ReadLine(), out varNumber);
            } while (erg == false || varNumber < validMin || varNumber > validMax);

            return varNumber;
        }
    }
}
