﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kraschl_Christof_PLF01
{
    class UmsatzVerwaltung
    {
        int[,] umsatzMatrix;
        int numberOfVerkaeufer;
        int numberOfMonths = 12;


        public UmsatzVerwaltung()
        {
            numberOfVerkaeufer = 5;
            umsatzMatrix = new int[numberOfVerkaeufer, numberOfMonths];
            fillArray();
        }

        private void fillArray()
        {
            short fillNumberMonth = 100;
            byte fillNumberVerkaeufer = 0;
            for(int idxVerkaeufer = 0; idxVerkaeufer < numberOfVerkaeufer; idxVerkaeufer++)
            {
                for(int idxMonth = 0; idxMonth < numberOfMonths; idxMonth++)
                {
                    umsatzMatrix[idxVerkaeufer, idxMonth] = fillNumberMonth + fillNumberVerkaeufer;
                    fillNumberVerkaeufer += 10;
                }
                fillNumberVerkaeufer = 0;
                fillNumberMonth += 100;
            }
        }

        public int NumberOfVerkaeufer
        {
            get { return numberOfVerkaeufer; }
            set
            {
                if(value > 0)
                {
                    numberOfVerkaeufer = value;
                    umsatzMatrix = new int[numberOfVerkaeufer, numberOfMonths];
                    fillArray();
                }
            }
        }

        public int averageAllVerkaeuferYear()
        {
            int[] averageYear = new int[numberOfVerkaeufer];
            int average = 0;

            for (int idxVerkaeufer = 0; idxVerkaeufer < numberOfVerkaeufer; idxVerkaeufer++)
            {
                for (int idxMonth = 0; idxMonth < numberOfMonths; idxMonth++)
                {
                    averageYear[idxVerkaeufer] += umsatzMatrix[idxVerkaeufer, idxMonth];
                }
            }
            for (int idxVerkaeufer = 0; idxVerkaeufer < numberOfVerkaeufer; idxVerkaeufer++)
            {
                average += averageYear[idxVerkaeufer];
            }
            average /= numberOfVerkaeufer;
            return average;
        }
 
        public int averageAllVerkaeuferMonth()
        {
            int average = 0;
            int numberOfFields = 0;

            numberOfFields = numberOfVerkaeufer * numberOfMonths;

            for (int idxVerkaeufer = 0; idxVerkaeufer < numberOfVerkaeufer; idxVerkaeufer++)
            {
                for (int idxMonth = 0; idxMonth < numberOfMonths; idxMonth++)
                {
                    average += umsatzMatrix[idxVerkaeufer, idxMonth];
                }
            }
            average /= numberOfFields;

            return average;
        }

        public int averageVerkaeuferYear(int idxVerkaeufer)
        {
            int average = 0;
            if (idxVerkaeufer >= 0 && idxVerkaeufer < numberOfVerkaeufer)
            {
                for (int idxMonth = 0; idxMonth < numberOfMonths; idxMonth++)
                {
                    average += umsatzMatrix[idxVerkaeufer, idxMonth];
                }
                average /= numberOfMonths;
            }
            else
            {
                average = -1;
            }
            return average;
        }
    }
}
