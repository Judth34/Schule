﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Breschan_Moritz_PLF1
{
    class Program
    {
        static void Main(string[] args)
        {
            UmsatzArray Umsaetze = new UmsatzArray();
            int maxVerkaeufer;
            int Umsatz;
            int Monate = 12;
            int monat;
            double average;

            maxVerkaeufer = GetValidNumber("Wieviele Verkäufer gibt es?", 1, 100);
            Umsaetze.Verkaeufer = maxVerkaeufer;
            for (int MonthCounter = 0; MonthCounter < Monate; MonthCounter++)
            {
                for (int VerkaeuferCounter = 0; VerkaeuferCounter < maxVerkaeufer; VerkaeuferCounter++)
                {
                    Umsatz = GetValidNumber("Welchen Umsatz hat der " + (VerkaeuferCounter + 1) + ".Verkaeufer im" + (MonthCounter + 1) + ".Monat", 0, 1000);
                    Umsaetze.SaveUmsatz(VerkaeuferCounter, MonthCounter, Umsatz);
                }
            }
            //Umsaetze.GenerateTestData();

            monat = GetValidNumber("Bitte Geben sie den Monat ein dessen Durchschnittsumsatzmsatz berechnet werden soll.", 1, Monate);
            Umsaetze.MonthAverage(monat,out average);
            Console.WriteLine("Der Durchschnittsumsatz dieses Monats beträgt:" + average);

            average = Umsaetze.VerkaeuferAllAverage();
            Console.WriteLine("Der Durchschnittsumsatz beträgt " + average);

            for (int VerkaeuferCounter = 0; VerkaeuferCounter < maxVerkaeufer; VerkaeuferCounter++)
            {
                Umsaetze.VerkaeuferAverage(VerkaeuferCounter, out average);
                Console.WriteLine("Der Durchschnittsumsatz des" + (VerkaeuferCounter + 1) + ".Verkaeufers betraegt:" + average);
            }

        }
        static int GetValidNumber(string Text, int min, int max)
        {
            int zahl;
            bool zahlGueltig;
            do
            {
                Console.WriteLine(Text + " (" + min + "-" + max + ")");
                zahlGueltig = int.TryParse(Console.ReadLine(), out zahl);
            } while (!zahlGueltig || zahl < min || zahl > max);

            return zahl;
        }
    }
}
