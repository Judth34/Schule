﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Breschan_Moritz_PLF1
{
    class UmsatzArray
    {
        #region Werte
        int[,] UmsatzMatrix;
        int monate;
        int verkaeufer;
        #endregion

        #region Konstruktor(en)
        public UmsatzArray()
        {
            monate = 12;
            verkaeufer = 5;
            UmsatzMatrix = new int[verkaeufer, monate];
        }
        #endregion

        #region Properties
        public int Verkaeufer
        {
            set
            {
                if (value > 0)
                {
                    verkaeufer = value;
                    UmsatzMatrix = new int[verkaeufer, monate];
                }
            }
            get
            {
                return verkaeufer;
            }
        }
        #endregion

        #region PublicMethods
        public void GenerateTestData()
        {
            for (int verkaeuferCounter = 0; verkaeuferCounter < verkaeufer; verkaeuferCounter++)
            {
                for (int monthCounter = 0; monthCounter < monate; monthCounter++)
                {
                    UmsatzMatrix[verkaeuferCounter, monthCounter] = 3;
                }
            }
        }

        public int SaveUmsatz(int VerkaeuferIdx, int MonthIdx, int Umsatz)
        {
            int rgw = 0;
            rgw += checkIdx(VerkaeuferIdx, MonthIdx);
            if (rgw == 0)
            {
                UmsatzMatrix[VerkaeuferIdx, MonthIdx] = Umsatz;
            }

            return rgw;
        }

        public double VerkaeuferAllAverage()
        {
            double average = 0;
            double temp = 0;
            int counter = 0;
            for (int verkaeuferCounter = 0; verkaeuferCounter < verkaeufer; verkaeuferCounter++)
            {
                VerkaeuferAverage(verkaeuferCounter, out temp);
                average += temp;
                counter++;
            }
            average /= counter;
            return average;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Verkaeufer"></param>
        /// <param name="average"></param>
        /// <returns>0=success/1=wrong verkaeuferIdx</returns>
        public int VerkaeuferAverage(int Verkaeufer, out double average)
        {
            int rgw = 0;
            rgw = checkVerkaeuferIdx(Verkaeufer);
            average = 0;
            if (rgw == 0)
            {
                for (int verkaeuferIdx = 0; verkaeuferIdx < verkaeufer; verkaeuferIdx++)
                {
                    average += UmsatzMatrix[Verkaeufer, verkaeuferIdx];
                }
                average /= verkaeufer;
            }
            return rgw;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Month"></param>
        /// <param name="average"></param>
        /// <returns>0=success/10=WrongMonthIdx</returns>
        public int MonthAverage(int Month, out double average)
        {
            int rgw = 0;
            average = 0;
            int counter = 0;
            if (rgw == 0)
            {
                for (int verkaeuferIdx = 0; verkaeuferIdx < verkaeufer; verkaeuferIdx++)
                {
                    average += UmsatzMatrix[verkaeuferIdx, Month];
                    counter += 1;
                }
                average /= counter;
            }
            return rgw;
        }
        #endregion

        #region PrivateMethods
        private int checkIdx(int VerkaeuferIdx, int MonthIdx)
        {
            int rgw = 0;
            rgw += checkVerkaeuferIdx(VerkaeuferIdx);
            rgw += checkMonthIdx(MonthIdx);
            return rgw;
        }

        public int checkVerkaeuferIdx(int VerkaeuferIdx)
        {
            int rgw = 0;
            if (VerkaeuferIdx < 0 || VerkaeuferIdx > verkaeufer)
            {
                rgw += 1;
            }
            return rgw;
        }

        public int checkMonthIdx(int MonthIdx)
        {
            int rgw = 0;
            if (MonthIdx < 0 || MonthIdx > monate)
            {
                rgw += 10;
            }
            return rgw;
        }
        #endregion

    }
}
