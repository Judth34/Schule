﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gragger_Nicolas_PLF01
{
    class Umsatzverwaltung
    {
        double[,] Umsaetze;
        int Ver;
        public int AnzVerkaeufer        {
            set
            {
                if (value >= 0)
                {
                    Umsaetze = new double[value, 12];
                    int Umsatzbasis = 0;
                    for (int idxVerkaeufer = 0; idxVerkaeufer < value; idxVerkaeufer++)
                    {
                        int Umsatzzusatz = 0;
                        Umsatzbasis += 100;
                        for (byte idxMonate = 0; idxMonate < 12; idxMonate++)
                        {
                            Umsaetze[idxVerkaeufer, idxMonate] = Umsatzbasis + Umsatzzusatz;
                            Umsatzzusatz += 10;
                        }
                    }
                }
            }
            get
            {
                return 2;
            }
        }

        public double DurchschnittMonat(byte Monat)
        {
            double result = 0;
            if (Monat >= 0 && Monat <= 12)
            {
                Monat--;
                for (int idxVerkaeufer = 0; idxVerkaeufer < AnzVerkaeufer; idxVerkaeufer++)
                {
                    result += Umsaetze[idxVerkaeufer, Monat];
                }
                result = result / AnzVerkaeufer;
            }
            else
            {
                result = -1;
            }
            return result;
        }

        public double DurchschnittJahr()
        {
            double result = 0;

            for (byte i = 1; i <= 12; i++)
            {
                result += DurchschnittMonat(i);
            }
            result = result / 12;
            return result;
        }
        public double VerkaeuferDurchschnitt(int Verkaeufer)
        {
            double result = -1;
            if (Verkaeufer > 0 && Verkaeufer <= AnzVerkaeufer)
            {
                for (byte idxMonat = 0; idxMonat <12; idxMonat++)
                {
                    result += Umsaetze[Verkaeufer - 1, idxMonat];  
                }
                result = result / 12;
            }
            return result;

        }
    }
}

