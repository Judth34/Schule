﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gragger_Nicolas_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
       

            Umsatzverwaltung Umsaetze = new Umsatzverwaltung();
         
            int anzVerkäufer=5;
            Console.WriteLine("sads");
            Umsaetze.AnzVerkaeufer = 5;
            Console.WriteLine("sads");
            Console.WriteLine(Umsaetze.AnzVerkaeufer);
            Console.WriteLine("Durchschnitt Jahr: "+Umsaetze.DurchschnittJahr());
            Console.WriteLine("Durchschnitt Monat : "+Umsaetze.DurchschnittMonat(1));
            Console.WriteLine("DurchsnittVerkäufer: "+Umsaetze.VerkaeuferDurchschnitt(3));
        }
    }
}
