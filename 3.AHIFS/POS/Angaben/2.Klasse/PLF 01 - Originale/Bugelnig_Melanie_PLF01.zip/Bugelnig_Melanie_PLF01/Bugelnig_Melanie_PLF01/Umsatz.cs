﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bugelnig_Melanie_PLF01
{
    class Umsatz
    {
        int anzahlVerkaeufer;
        int validMonthMax = 12;
        int[,] umsaetze;
        int sum=0;

        #region Konstruktor(en)
        public Umsatz()
        {
            this.anzahlVerkaeufer=5;
            umsaetze = new int[anzahlVerkaeufer, validMonthMax];
        }
        #endregion

        public int GetMonth()
        {
            return validMonthMax;
        }
        public int AnzahlDerVerkaeufer
        {
            get
            {
                return anzahlVerkaeufer;
            }

            set
            {
                if (value > 0)
                {
                    anzahlVerkaeufer = value;
                    umsaetze = new int[anzahlVerkaeufer, validMonthMax];
                }
            }


        }

        public int SaveUmsatz(int verkauferIdx, int monatIdx, int Umsatz)
        {

            int result=0;

            if (monatIdx < 0 || monatIdx > validMonthMax)
            {
                result = result + 1;
            }

            if (verkauferIdx < 0 || verkauferIdx > anzahlVerkaeufer)
            {
                result += 10;
            }


            if (result == 0)
            {
                umsaetze[verkauferIdx, monatIdx] = Umsatz;
            }

            return result;
        }

        public double AverageAllPerMonth()
        {
            for (int monatIdx = 0; monatIdx < validMonthMax; monatIdx++)
            {

                for (int verkaeuferIdx = 0; verkaeuferIdx < AnzahlDerVerkaeufer; verkaeuferIdx++)
                {
                    sum = sum + umsaetze[monatIdx, verkaeuferIdx];
                }


            }

            return (double)(sum / validMonthMax);
        }

        public double AverageAllPerYear()
        {
            for (int verkauferIdx = 0; verkauferIdx < AnzahlDerVerkaeufer; verkauferIdx++)
            {

                for (int monatIdx = 0; monatIdx < validMonthMax; monatIdx++)
                {
                    sum = sum + umsaetze[monatIdx, verkauferIdx];
                }


            }

           return (double)(sum / validMonthMax);
        }

        public double AverageOnePerMonth(int verkauferIdx)
        {

            for (int monatIdx = 0; monatIdx < validMonthMax; monatIdx++)
            {
                sum = sum + umsaetze[monatIdx, verkauferIdx];
            }

            return (double)(sum / validMonthMax);
        }

    }


}
