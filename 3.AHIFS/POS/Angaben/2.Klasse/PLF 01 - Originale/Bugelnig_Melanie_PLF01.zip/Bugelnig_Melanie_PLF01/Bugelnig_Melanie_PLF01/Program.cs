﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bugelnig_Melanie_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            int umsatz;
            Umsatz allUmsaetze = new Umsatz();



            allUmsaetze.AnzahlDerVerkaeufer = getNumber("Wie viele Verkäufer soll es geben: ");

            for (int verkauferIdx = 0; verkauferIdx < allUmsaetze.AnzahlDerVerkaeufer; verkauferIdx++)
            {
                Console.WriteLine("\n\n" + (verkauferIdx + 1) + ". Verkäufer: \n");

                for (int monatIdx = 0; monatIdx < allUmsaetze.GetMonth(); monatIdx++)
                {
                    umsatz = getNumber("Gib den " + (monatIdx + 1) + ". Umsatz ein:");
                    allUmsaetze.SaveUmsatz(verkauferIdx, monatIdx, umsatz);

                    while (allUmsaetze.SaveUmsatz(verkauferIdx, monatIdx, umsatz) > 0)
                    {
                        Console.WriteLine("Fehler Nr.: " + allUmsaetze.SaveUmsatz(verkauferIdx, monatIdx, umsatz));
                        Console.WriteLine(" \n 11 = ungültiger Monat & Verkäufer \n10 =ungültiger Monat\n01 = ungültiger Verkäufern \n");

                    }
                }
            }

            Console.WriteLine("Der Durchschnittsumsatz aller Verkaufer pro Monat ist: " + allUmsaetze.AverageAllPerMonth());
            Console.WriteLine("Der Durchschnittsumsatz aller Verkäufer pro Jahr" + allUmsaetze.AverageAllPerYear());
            Console.WriteLine("Der Durchschnittsumsatz dieses Verkäufers pro Monat ist: " + allUmsaetze.AverageOnePerMonth(getNumber("Geben Sie die Verkaufernummer ein für die Berechnung des Monatzumsatzes dieses Verkäufers: ")));

        }
        static int getNumber(string message)
        {
            bool erg;
            int number;

            do
            {
                Console.WriteLine(message);
                erg = int.TryParse(Console.ReadLine(), out number);
            } while (erg == false);

            return number;
        }
    }
}