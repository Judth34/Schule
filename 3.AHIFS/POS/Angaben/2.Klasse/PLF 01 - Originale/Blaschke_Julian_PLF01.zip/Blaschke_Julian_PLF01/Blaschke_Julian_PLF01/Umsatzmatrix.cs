﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blaschke_Julian_PLF01
{
    class Umsatzmatrix
    {
        #region initialisieren
        private int[,] verkäuferundUsaetze;
        private int verkaeufer;
        #endregion

        #region Konstructor
        public Umsatzmatrix ()
        {
            verkaeufer = 1; 
            verkäuferundUsaetze = new int[verkaeufer, 12];
        }
        #endregion

        #region Properties
        public int Verkaeufer
        {
            get { return verkaeufer; }
            set
            {
                if ((value > 0) && (value < 1000) )
                {
                    verkaeufer = value;
                    verkäuferundUsaetze = new int[verkaeufer, 12];
                }
            }
        }
        #endregion

        #region Werte einspeichern 
        public bool WertindieMatrixeintragen (int Wert,int verkaeuferidx,int monatidx)
        {
            bool result = true;
            
            if ((Wert < 0) || (Wert > 100000))
            {
                result = false;
            }

            result = ueberpruefen(verkaeuferidx,monatidx);

            if (result == true)
            {
                verkäuferundUsaetze[verkaeuferidx, monatidx] = Wert;
            }
            return result; 
        }
        #endregion

        #region durchschnitte
        public int durchschnittzahlenproJahrvoneinem(int Verkaeufer)
        {
            bool result = true;
            int durchschnittswert = 0;
            
            if ((Verkaeufer < 0) || (Verkaeufer > verkaeufer))
            {
                result = false;
            }
            if (result == true)
            {
                for(int i = 0; i < 12; i++)
                {
                    durchschnittswert = durchschnittswert + verkäuferundUsaetze[Verkaeufer,i];
                }
                durchschnittswert /= 12;
            }

            return durchschnittswert;
        }
  
        public int durchschnittzahlenproJahrvonallen ()
        {
            int [] durchschnittswert = new int [verkaeufer];
            int endgueltigerdurchschnitt = 0;

            for (int i = 0; i < 12; i++)
            {

                durchschnittswert[i] += verkäuferundUsaetze[Verkaeufer, i];
            }
                
            for (int i = 0; i < verkaeufer; i++)
            {
                endgueltigerdurchschnitt+= durchschnittswert[i];
            }

            endgueltigerdurchschnitt /= Verkaeufer;
            return endgueltigerdurchschnitt;
        }

        public int durchschnittzahlenproMonat(int Monat)
        {
            bool result = true;
            int durchschnitt = 0;
           if ((Monat<1) || (Monat>12))
            {
                result = false;
            }
           if (result)
            {
                for (int i = 0; i< 12;i++)
                {
                    durchschnitt += verkäuferundUsaetze[i, Monat]; 
                }
                durchschnitt /= 12;  
            }
            return durchschnitt;
        }

        #endregion

        #region private Methoden
        private bool ueberpruefen (int verkaeuferidx, int monatidx)
    {
            bool result = true;
            if ((verkaeuferidx < 1) || (verkaeuferidx > verkaeufer))
            {
                result = false;
            }
            if ((monatidx < 1) || (monatidx > 12))
            {
                result = false;
            }

            return result;
        }
        #endregion
    }
}
