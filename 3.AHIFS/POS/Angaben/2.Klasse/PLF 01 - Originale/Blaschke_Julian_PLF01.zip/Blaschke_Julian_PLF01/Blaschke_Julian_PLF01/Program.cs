﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blaschke_Julian_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            Umsatzmatrix m1 = new Umsatzmatrix();
            m1.Verkaeufer = 10;
            Console.WriteLine(m1.Verkaeufer);

            definierteWerteeinlesen(m1);

        }

        static void definierteWerteeinlesen(Umsatzmatrix m1)
        {
            for (int verkäuferidx = 0; verkäuferidx < m1.Verkaeufer; verkäuferidx++)
            {
                for (int monatidx = 0; monatidx < 12; monatidx++)
                {
                    m1.WertindieMatrixeintragen((((verkäuferidx + 1) * 100) + ((monatidx + 1) * 10)), verkäuferidx, monatidx);
                }
            }

        }
    }
}

    
