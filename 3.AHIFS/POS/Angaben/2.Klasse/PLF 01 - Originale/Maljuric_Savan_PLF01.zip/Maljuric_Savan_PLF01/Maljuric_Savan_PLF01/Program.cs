﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maljuric_Savan_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            Durchschnittumsatz durchschnitt = new Durchschnittumsatz();

            durchschnitt.Verkäufer = GetValidNumber(1,10,"Wie viele Verkäufer soll es geben: ");

            einlesen(durchschnitt);
            printarray(durchschnitt);
            Console.WriteLine(durchschnitt.Durchschnittsjahr());
            durchschnittmonat(durchschnitt);
        }

        private static void einlesen(Durchschnittumsatz durchschnitt)
        {
            int startwert = 100;

            for (int IdxVerkäufer = 0; IdxVerkäufer < durchschnitt.Verkäufer; IdxVerkäufer++)
            {
                for (int Idxmonate = 0; Idxmonate < 12; Idxmonate++)
                {
                    durchschnitt.Savearrray(IdxVerkäufer, Idxmonate, startwert);
                    startwert = startwert + 10;
                }
                startwert = startwert * 2;
            }
        }

        private static void durchschnittmonat(Durchschnittumsatz durchschnitt)
        {
            for(int IdxMonate=0;IdxMonate < 12;IdxMonate++)
            {
                Console.WriteLine(durchschnitt.Durchschnittsmonat(IdxMonate));
            }
        }

        private static int GetValidNumber(int min, int max, string message)
        {
            int rgw;
            string eingabe;
            bool control;

            do
            {
                Console.WriteLine(message);
                eingabe = Console.ReadLine();
                control = int.TryParse(eingabe, out rgw);
            } while (rgw < min || rgw > max || control == false);

            return rgw;
        }

        static void printarray(Durchschnittumsatz durchschnitt)
        {

            for (int IdxVerkäufer = 0; IdxVerkäufer < durchschnitt.Verkäufer; IdxVerkäufer++)
            {
                for (int Idxmonate = 0; Idxmonate < 12; Idxmonate++)
                {
                    Console.WriteLine(durchschnitt.Printarray(IdxVerkäufer,Idxmonate));
                }
                
            }
        }
    }
}
