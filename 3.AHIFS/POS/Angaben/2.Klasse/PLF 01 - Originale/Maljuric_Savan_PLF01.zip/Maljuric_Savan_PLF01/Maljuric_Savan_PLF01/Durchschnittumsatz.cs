﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maljuric_Savan_PLF01
{
    class Durchschnittumsatz
    {

        #region Eigenschaften
        private int verkäufer;
        private int monate;
        private int[,] umsatz;
        #endregion

        #region Konstruktor
        public void Maljuric_Savan_PLF01()
        {
            monate = 12;
            umsatz = new int[verkäufer, monate];
        }
        #endregion

        #region Properties
        public int Verkäufer
        {
            get { return verkäufer; }
            set
            {
                if (value > 1)
                {
                    verkäufer = value;
                    umsatz = new int[verkäufer, monate];
                }
                else
                {
                }
            }
        }
        #endregion

        #region Methoden

        public void Savearrray(int IdxVerkäufer, int IdxMonate,int wert) 
        {
            umsatz[IdxVerkäufer, IdxMonate] = wert;
        }

        public int Printarray(int IdxVerkäufer, int IdxMonate)
        {
            return umsatz[IdxVerkäufer, IdxMonate];
        }

        public double Durchschnittsjahr()
        {
            int summe = 0;
            double ergebnis=0;

            for (int IdxVerkäufer = 0; IdxVerkäufer < verkäufer; IdxVerkäufer++)
            {
                for (int IdxMonate = 0; IdxMonate < monate; IdxMonate++)
                {
                    summe = summe + umsatz[IdxVerkäufer, IdxMonate];
                } 
            }

            ergebnis = (double) summe / monate;

            return ergebnis;
        }

        public double Durchschnittsmonat(int IdxMonat)
        {
            int summe = 0;
            double ergebnis = 0;
            double[] array = new double[monate];

            for (int IdxMonate = 0; IdxMonate < monate; IdxMonate++)
            {
                for (int IdxVerkäufer = 0; IdxVerkäufer < verkäufer; IdxVerkäufer++)
                {
                    summe = summe + umsatz[IdxVerkäufer, IdxMonate];
                }
                ergebnis = summe / verkäufer;
                array[IdxMonate] = ergebnis; // speichern im array
                summe = 0;
            }

            return array[IdxMonat];
        }

        #endregion

    }
}

