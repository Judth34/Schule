﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Winkler_Christian_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            byte verkaeufer = 0;
            double averageMonthSeller = 0;
            double averageMonth = 0;
            double averageYear = 0;
            byte verkaeuferMonthSeller = 0;

            verkaeufer = getValidNumber(1,5,"Wie viele Verkäufer soll es geben: ");
            Console.Clear();
            Umsaetze umsaetze1 = new Umsaetze();
            umsaetze1.Verkaeufer = verkaeufer;

            umsaetze1.fillArraySchema();

            getAverage(ref averageMonthSeller, ref averageMonth, ref averageYear, verkaeuferMonthSeller, umsaetze1, verkaeufer);
        }
        static void getAverage(ref double averageMonthSeller, ref double averageMonth, ref double averageYear, byte verkaeuferMonthSeller, Umsaetze umsaetze1, byte verkaeufer)
        {
            averageMonth = umsaetze1.averageMonth();
            Console.WriteLine("Der Durchschnittsumsatz aller Verkäufer pro Monat ist: " + averageMonth);

            averageYear = umsaetze1.averageYear();
            Console.WriteLine("Der Durchschnittsumsatz aller Verkäufer pro Jahr ist: " + averageYear);

            verkaeuferMonthSeller = getValidNumber(1, verkaeufer, "Geben Sie die Verkäufer Nummer ein für die Berechnung des Monatsumsatzes dieses Verkäufers: ");
            averageMonthSeller = umsaetze1.averageMonthSeller(verkaeuferMonthSeller);
            Console.WriteLine("Der Durchschnittsumsatz des Verkäufers pro Monat ist: " + averageMonthSeller);

        }
        static byte getValidNumber(int min, int max, string message)
        {
            byte eingabe = 0;
            bool erg;
            do
            {
                Console.Write(message);
                erg = byte.TryParse(Console.ReadLine(), out eingabe);
            } while (erg == false || eingabe < min || eingabe > max);
            return eingabe;
        }
    }
}
