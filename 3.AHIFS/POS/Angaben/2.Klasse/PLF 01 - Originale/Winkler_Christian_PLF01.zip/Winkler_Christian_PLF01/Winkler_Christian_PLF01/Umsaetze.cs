﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Winkler_Christian_PLF01
{
    class Umsaetze
    {
        #region Preferences
        private byte monate = 12;
        private byte verkaeufer;
        private int[,] umsaetze;
        #endregion
        #region Constructor
        public Umsaetze()
        {
            byte monate = 12;
            byte verkaeufer = 5;
            umsaetze = new int[monate, verkaeufer];
        }
        #endregion
        #region Properties
        public byte Verkaeufer
        {
            get { return verkaeufer; }
            set
            {
                if(value > 0 && value <= 5)
                {
                    verkaeufer = value;
                    umsaetze = new int[monate, verkaeufer];
                }
            }
        }
        #endregion
        #region Methods
        public void fillArraySchema()
        {
            int betrag;
            for (int verkaeuferIdx = 0; verkaeuferIdx < verkaeufer; verkaeuferIdx++)
            {
                betrag = ((verkaeuferIdx + 1) * 100);
                for (int monatIdx = 0; monatIdx < monate; monatIdx++)
                {
                    umsaetze[monatIdx, verkaeuferIdx] = betrag;
                    //Console.WriteLine(umsaetze[monatIdx, verkaeuferIdx]);
                    betrag += 10;
                }
            }
        }
        public double averageYear()
        {
            int sum = 0;
            int sumForDiv = 0;
            for (int verkaeuferIdx = 0; verkaeuferIdx < verkaeufer; verkaeuferIdx++)
            {
                for (int monatIdx = 0; monatIdx < monate; monatIdx++)
                {
                    sum += umsaetze[monatIdx, verkaeuferIdx];
                }
            }
            sumForDiv = verkaeufer * monate;
            return ((double)sum / verkaeufer);
        }
        public double averageMonth()
        {
            int sum = 0;
            int sumForDiv = 0;
            for (int verkaeuferIdx = 0; verkaeuferIdx < verkaeufer; verkaeuferIdx++)
            {
                for (int monatIdx = 0; monatIdx < monate; monatIdx++)
                {
                    sum += umsaetze[monatIdx, verkaeuferIdx];
                }
            }
            sumForDiv = verkaeufer * monate;
            return ((double)sum / sumForDiv);
        }
        public double averageMonthSeller(byte verkaeuferIdx)
        {
            int sum = 0;
            if (verkaeufer > 0 && verkaeufer < 6)
            {  
                verkaeuferIdx--; //Bei 1. Verkäufer = 0. Stelle
                for (int monatIdx = 0; monatIdx < monate; monatIdx++)
                {
                    sum += umsaetze[monatIdx, verkaeuferIdx];
                }
            }
            return ((double)sum / monate);
        }
        #endregion
    }
}
