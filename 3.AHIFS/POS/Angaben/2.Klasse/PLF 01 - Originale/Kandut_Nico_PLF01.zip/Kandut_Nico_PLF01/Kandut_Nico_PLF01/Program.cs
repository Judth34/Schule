﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kandut_Nico_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            int DurchschnittAllerVerkaeuferProMonat;
            int DurchschnittAllerVerkaeuferDesJahres;
            int DurchschnittEinesVerkaeufers;
            Umsaetze UmsaetzeStatistik = new Umsaetze();

            
            UmsaetzeStatistik.NumberOfSalesmen = 5;

            Console.WriteLine(UmsaetzeStatistik.NumberOfSalesmen);

            UmsaetzeStatistik.generateMoneyArray();

            //DurchschnittAllerVerkaeuferProMonat = UmsaetzeStatistik.DurchschnittAllerVerkaeuferProMonat(3);
            //DurchschnittAllerVerkaeuferDesJahres = UmsaetzeStatistik.DurchschnitteAllerVerkaeuferProJahr();
            DurchschnittEinesVerkaeufers = UmsaetzeStatistik.DurchschnittEinesVerkaeufers(3);
            //Console.WriteLine(DurchschnittAllerVerkaeuferProMonat);
            //Console.WriteLine(DurchschnittAllerVerkaeuferDesJahres);
            Console.WriteLine(DurchschnittEinesVerkaeufers);

        }
    }
}
