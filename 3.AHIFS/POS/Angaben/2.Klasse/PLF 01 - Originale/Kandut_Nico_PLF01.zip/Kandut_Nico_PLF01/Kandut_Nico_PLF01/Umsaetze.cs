﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kandut_Nico_PLF01
{
    class Umsaetze
    {
        private byte numberOfSalesmen;
        private byte numberOfMonths = 12;
        private byte minSalesmen = 1;
        private byte maxSalesmen = 10;
        private short[,] MoneyArray;

        public byte NumberOfSalesmen
        {
            get { return numberOfSalesmen; }
            set
            {
                if(value > minSalesmen && value < maxSalesmen)
                {
                    numberOfSalesmen = value;
                }
            }
        } 

        /// <summary>
        /// 
        /// </summary>
        /// <returns>-1 = 0 Verkäufer; 1 = zu viele Verkäufer; 0 = richtig; </returns>
        public sbyte generateMoneyArray()
        {
            sbyte result = 0;
            if (NumberOfSalesmen < minSalesmen)
            {
                MoneyArray = new short[NumberOfSalesmen, numberOfMonths];
                result = -1;
            }

            if (NumberOfSalesmen > maxSalesmen)
            {
                result = 1;
            }

            if (result == 0)
            {
                MoneyArray = new short[NumberOfSalesmen, numberOfMonths];
                fill();
            }
            return result;
        }

        private void fill()
        {
            short SalesmenModifier = 100;
            short MonthModifier = 0;

            for(byte SalesmenIdx = 0; SalesmenIdx < NumberOfSalesmen; SalesmenIdx++)
            {
                for (byte MonthIdx = 0; MonthIdx < numberOfMonths; MonthIdx++)
                {                 
                    MoneyArray[SalesmenIdx, MonthIdx] = (short)(SalesmenModifier + MonthModifier);
                    MonthModifier += 10;
                    SalesmenModifier += 100;      
                }
            }
        }

        public int DurchschnittAllerVerkaeuferProMonat(byte MonthIdx)
        {
            int result = 0;

            if (checkMonthIdx(MonthIdx) == true)
            {
                for (byte SalesmenIdx = 0; SalesmenIdx < NumberOfSalesmen; SalesmenIdx++)
                {
                    result += MoneyArray[SalesmenIdx, (MonthIdx - 1)];
                }

                result = result / this.NumberOfSalesmen;
                
            }
            return result;
        }

        public int DurchschnittEinesVerkaeufers(byte SalesmenIdx)
        {
            int result = 0;

            if (checkSalesmenIdx(SalesmenIdx) == true)
            {
                for (byte MonthIdx = 0; MonthIdx < numberOfMonths; MonthIdx++)
                {
                    result += MoneyArray[(SalesmenIdx - 1), MonthIdx];
                }
            }
            result = result / numberOfMonths;
            return result;
        }

        public int DurchschnitteAllerVerkaeuferProJahr()
        {
            int result = 0;

            for (byte SalesmenIdx = 0; SalesmenIdx < NumberOfSalesmen; SalesmenIdx++)
            {
                for (byte MonthIdx = 0; MonthIdx < NumberOfSalesmen; MonthIdx++)
                {
                    result += MoneyArray[(SalesmenIdx - 1), MonthIdx];
                }
                result = result / numberOfMonths;
            }
            result = result / NumberOfSalesmen;

            return result;
        }

        private bool checkMonthIdx(byte MonthIdx)
        {
            bool result = true;

            if(MonthIdx < 1 || MonthIdx > 12)
            {
                result = false;
            }
            return result;
        }

        private bool checkSalesmenIdx(byte SalesmenIdx)
        {
            bool result = true;

            if (SalesmenIdx < 1 || SalesmenIdx > NumberOfSalesmen)
            {
                result = false;
            }
            return result;
        }
    }
}
