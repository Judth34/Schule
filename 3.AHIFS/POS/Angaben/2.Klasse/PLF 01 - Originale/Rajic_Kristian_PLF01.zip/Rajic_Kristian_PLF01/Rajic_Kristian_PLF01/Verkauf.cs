﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rajic_Kristian_PLF01
{
    class Verkauf
    {
        private int anzahlVerkaeufer;
        private int[,] umsatzMatrix;

        public int AnzahlVerkaefer
        {
            get { return anzahlVerkaeufer; }
            set
            {
                anzahlVerkaeufer = value;
                umsatzMatrix = new int[anzahlVerkaeufer, 12];
            }
        }

        public void SaveUmsaetze(int NummerVekaeufer, int NummerMonats, int Umsatz)
        {
            umsatzMatrix[NummerVekaeufer, NummerMonats] = Umsatz;
            
        }

        public int DurchschnittMonat()
        {
            int Durchschnitt = 0;

            Durchschnitt = SummeUmsaetze();

            return Durchschnitt / umsatzMatrix.Length;
        }

        public int DurchschnittJahr()
        {
            int Durchschnitt = 0;

            Durchschnitt = SummeUmsaetze();

            return Durchschnitt / anzahlVerkaeufer;
        }

        public int DurchschnittVekaeufer(int NummerVekauefer)
        {
            int Umsatz = 0;
            for (int CounterUmsaetze = 0; CounterUmsaetze < 12; CounterUmsaetze++ )
            {
                Umsatz = Umsatz + umsatzMatrix[NummerVekauefer, CounterUmsaetze];
            }

            return Umsatz / 12;
        }

        private int SummeUmsaetze()
        {
            int Durchschnitt = 0;
            for (int Counterverkauefer = 0; Counterverkauefer < umsatzMatrix.GetLength(0); Counterverkauefer++)
            {
                for (int Countermonat = 0; Countermonat < umsatzMatrix.GetLength(1); Countermonat++)
                {
                    Durchschnitt = Durchschnitt + umsatzMatrix[Counterverkauefer, Countermonat];
                }
            }
            return Durchschnitt;
        }

    }
}
