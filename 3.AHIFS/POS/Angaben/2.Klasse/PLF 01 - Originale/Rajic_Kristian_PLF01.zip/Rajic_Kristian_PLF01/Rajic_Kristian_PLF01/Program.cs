﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rajic_Kristian_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            int Umsatz = 100;
            Verkauf Umsaetze = new Verkauf();
            Umsaetze.AnzahlVerkaefer = GetValidNumber(1, 50, "Wie viele verkaeufer soll es geben? ( min.1; max.50)");

            for (int Verkaeuferidx = 0; Verkaeuferidx < Umsaetze.AnzahlVerkaefer; Verkaeuferidx++)
            {
                for (int monatidx = 0; monatidx < 12; monatidx++) 
                {
                    Umsaetze.SaveUmsaetze(Verkaeuferidx, monatidx, Umsatz);
                    Umsatz = Umsatz + 10;
                    
                }
            }

            
            Console.WriteLine(Umsaetze.DurchschnittMonat());
            Console.WriteLine(Umsaetze.DurchschnittJahr());
            Console.WriteLine(Umsaetze.DurchschnittVekaeufer(GetValidNumber(1, Umsaetze.AnzahlVerkaefer, "Geben Sie die verkaufernummer fuer die berechnung des Monatumsatzen ein.")));
            
        }

        static int GetValidNumber(int Anfang, int ende, string Text)
        {
            int i;
            bool erg;
            do
            {
                do
                {
                    Console.Write(Text);
                    erg = int.TryParse(Console.ReadLine(), out i);

                } while (erg == false);

            } while (i < Anfang || i > ende);


            return i;
        }
    }
}
