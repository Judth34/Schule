﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Webhofer_Gabriel_PLF01
{
    class Umsatz
    {
        #region Eigenschaften
        private int verkaeufer;
        private int[,] umsatzMatrix;
        #endregion

        #region Konstruktor(en)
        public Umsatz()
        {
            verkaeufer = 5;
            umsatzMatrix = new int[12, verkaeufer];
        }
        #endregion

        #region Properties
        public int Verkaeufer
            {
            get{ return verkaeufer; }
            set
             {
                if (value <= 0)
                {

                }
                else
                {
                    verkaeufer = value;
                    umsatzMatrix = new int[12, verkaeufer];
                }
             }
            }
        #endregion

        #region Methods
        public bool DurchschnittMonat(int Monat, ref double Durchschnitt)
        {
            bool erg = false;
            int Summe = 0;
            if (Monat > 12 || Monat < 1)
            {

            }
            else
            {
                for (int VerkauferIdx = 0; VerkauferIdx < verkaeufer; VerkauferIdx++)
                {
                    Summe += umsatzMatrix[Monat - 1, VerkauferIdx];
                }
                Durchschnitt = (double)Summe / verkaeufer;
                erg = true;
            }
            return erg;
        }
        
        public bool DurchschnittVerkaufer(int Verkaufer, ref double Durchschnitt)
        {
            bool erg = false;
            int Summe = 0;
            if (Verkaufer < 0 || Verkaufer > verkaeufer)
            {

            }
            else
            {
                for (int MonatsIdx = 0; MonatsIdx < 12;MonatsIdx++)
                {
                    Summe += umsatzMatrix[MonatsIdx, Verkaufer - 1];
                }
                Durchschnitt = (double)Summe / 12;
                erg = true;
            }
            return erg;
        }
        public double DurchSchnittAlleMonat()
        {
            double Durchschnitt = 0;
            double ZwischenDurchSchnitt = 0;
            for (int MonatsIdx = 0; MonatsIdx < 12; MonatsIdx++)
            {
                for (int MonatIdx = 0; MonatIdx < verkaeufer; MonatIdx++)
                {
                    DurchschnittVerkaufer(MonatIdx + 1, ref ZwischenDurchSchnitt);
                    Durchschnitt += ZwischenDurchSchnitt;
                }
            }
            Durchschnitt /= (verkaeufer * 12);
            return Durchschnitt;
        }
        public void Befueller()
        {
            int Wert = 100;
            for (int MonatsIdx = 0; MonatsIdx < 12; MonatsIdx++)
            {
                for (int VerkauferIdx = 0; VerkauferIdx < verkaeufer; VerkauferIdx++)
                {
                    umsatzMatrix[MonatsIdx, VerkauferIdx] = Wert;
                    Wert += 100;
                }
                Wert = 100 + (10 * (MonatsIdx + 1));
            }
        }
        public double DurchSchnittAlleJahr()
        {
            double DurchSchnitt = 0;
            int ZwischenSumme = 0;
            for (int verkauferIdx = 0; verkauferIdx < verkaeufer; verkauferIdx ++)
            {
                for (int MonatsIdx = 0; MonatsIdx < 12; MonatsIdx++)
                {
                    ZwischenSumme += umsatzMatrix[MonatsIdx, verkauferIdx];
                }

            }
            DurchSchnitt = (double)ZwischenSumme / verkaeufer; 
            return DurchSchnitt;
        }
        #endregion
    }
}
