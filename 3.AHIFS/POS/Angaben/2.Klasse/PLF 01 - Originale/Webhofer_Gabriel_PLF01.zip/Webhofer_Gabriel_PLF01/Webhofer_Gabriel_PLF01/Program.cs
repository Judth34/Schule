﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Webhofer_Gabriel_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            Umsatz u1 = new Umsatz();
            double durchschnitt = 0;
            int Monat;
            int Verkaufer;
            u1.Verkaeufer = getValidNumber(1, 25, "Geben Sie die Anzahl der Verkäufer ein : ");
            u1.Befueller();
            Monat = getValidNumber(1,12,"Geben Sie den Monat ein : ");
            Console.WriteLine(u1.DurchschnittMonat(Monat, ref durchschnitt));
            Console.WriteLine("Der Durchschnitt des Monats {0} ist {1}",Monat,durchschnitt);
            Verkaufer = getValidNumber(1, u1.Verkaeufer, "Geben Sie den Verkaufer ein : ");
            Console.WriteLine(u1.DurchschnittVerkaufer(Verkaufer, ref durchschnitt));
            Console.WriteLine("Der Durchschnitt des {0}. Verkaufers pro Jahr ist : {1}",Verkaufer, durchschnitt);
            durchschnitt = u1.DurchSchnittAlleMonat();
            Console.WriteLine("Der Durchschnitt aller Verkäufer pro Monat ist : "+durchschnitt);
            durchschnitt = u1.DurchSchnittAlleJahr();
            Console.WriteLine("Der Durchschnitt aller Verkäufer pro Jahr ist : " + durchschnitt);
        }
        static int getValidNumber(int Untergrenze, int Obergrenze, string Message)
        {
            int i;
            bool erg;
            do
            {
                do
                {
                    Console.WriteLine(Message);
                    erg = int.TryParse(Console.ReadLine(), out i);
                } while (erg == false);
            } while ((i < Untergrenze) || (i > Obergrenze));
            return i;
        }
    }
}
