﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kumnig_Cora_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Variablen
            int wert = 100;
            int fehlermeldung;
            int bestimmterVerkaufer;
            double erg;
            Umsaetze u1 = new Umsaetze();
            #endregion

            #region Einlesen
            u1.NumberOfVerkaeufer = getValidNumber (1, 10, "Wie viele verkäufer soll es geben: [1-10]");
            u1.NumberOfMoths = 12;

            
            for (int IdxVerkaeufer = 0; IdxVerkaeufer < u1.NumberOfVerkaeufer; IdxVerkaeufer++)
            {
                     if (IdxVerkaeufer > 0)
                    {
                        wert = wert - 10;
                    }

                for (int IdxUmsatz = 0; IdxUmsatz < u1.NumberOfMoths; IdxUmsatz++)
                {
                   
                    if (IdxUmsatz > 0)
                    {
                        wert = wert + 10;
                    }

                    fehlermeldung = u1.SaveUmsatz(wert, IdxVerkaeufer, IdxUmsatz);
                    //Console.WriteLine("Fehlermeldung:" + fehlermeldung);
                    //Console.WriteLine("Der Umsatz für den {0} Verkäufer in dem {1} Monat ist: {2}", IdxVerkaeufer + 1, IdxUmsatz + 1, wert);
                }

            }
            #endregion

            #region Ausgabe
            erg = u1.DurchschnittAllerVerkaeuferProMonat();
            Console.WriteLine("Der Durchschnittsumsatz alle Verkäufer pro Monat ist:" + erg);
            erg = u1.DurchschnittAllerVerkaeuferProJahr();
            Console.WriteLine("Der Durchschnittsumsatz aller Verkäufer pro Jahr ist :" + erg);

            bestimmterVerkaufer = getValidNumber(1, u1.NumberOfVerkaeufer, "Geben Sie die Verkäufre Nummer einfür die Berechnung des Monatsumsatzes diseses Verkäufers:");
            erg = u1.DurchschnittEinesVerkaeuferProJahr(bestimmterVerkaufer);
            Console.WriteLine("Der Durchschnittsumsatz dieses Verkäufers pro Jahr ist :" + erg);

            #endregion
        }

        #region Abfrage
        static int getValidNumber(int validMin, int validMax, string userText)
        {
            bool erg;
            int varNumber;
            do
            {
                Console.WriteLine(userText);
                erg = int.TryParse(Console.ReadLine(), out varNumber);
            } while (erg == false || varNumber < validMin || varNumber > validMax);
            return varNumber;
        }

        #endregion
    }
}
