﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kumnig_Cora_PLF01
{
    class Umsaetze
    {
        #region Eigenschaften
        int numberOfVerkaeufer;
        int numberOfMoths;
        int[,] umsatz;
        #endregion

        #region Konstruktor(en)
        public Umsaetze ()
        {
            numberOfMoths = 12;
            numberOfVerkaeufer = 1;

            umsatz = new int [numberOfVerkaeufer, numberOfMoths];
        }
        #endregion

        #region Properties
        public int NumberOfVerkaeufer
        {
            get { return numberOfVerkaeufer; }
            set
            {
                if (value > 0)
                {
                    numberOfVerkaeufer = value;
                    umsatz = new int [numberOfVerkaeufer, numberOfMoths];
                }
            }
        }

        public int NumberOfMoths
        {
            get { return numberOfMoths; }
            set
            {
                if (value > 0 && value <= 12)
                {
                    numberOfMoths = value;
                    umsatz = new int[numberOfVerkaeufer, numberOfMoths];
                }
            }
        }
        #endregion

        #region private Methoden
        private int CheckIndises(int verkauferidx, int umsatzidx)
        {
            int result = 0;

            if (verkauferidx < 0 || verkauferidx > numberOfVerkaeufer)
            {
                result += 10;
            }
            if (umsatzidx < 0 || umsatzidx > numberOfMoths)
            {
                result += 100;
            }

            return result;
        }

        #endregion

        #region öffentliche Methoden

        public int SaveUmsatz(int wert, int verkauferidx, int umsatzidx)
        {
            int result = 0;
            if (wert < 1 || wert > 5)
            {
                result += 1;
            }
            result += CheckIndises(verkauferidx, umsatzidx);

            if (result == 0)
            {
                umsatz [verkauferidx, umsatzidx] = wert;
            }

            return result;
        }



        public double DurchschnittAllerVerkaeuferProMonat()
        {
            double erg = 0;

            for (int umsatzidx = 0; umsatzidx < numberOfMoths; umsatzidx++)
            {
                for (int verkauferidx = 0; verkauferidx < numberOfVerkaeufer; verkauferidx++)
                {
                    erg += umsatz[verkauferidx, umsatzidx];
                }
            }
            erg /= numberOfVerkaeufer;

            return erg;

        }
        public double DurchschnittEinesVerkaeuferProJahr(int verkauferidx)
        {
            double erg = 0;
            if (verkauferidx >= 0 && verkauferidx < numberOfVerkaeufer)
            {
                for (int umsatzidx = 0; umsatzidx < numberOfMoths; umsatzidx++)
                {
                    erg = erg + umsatz[verkauferidx, umsatzidx];
                }

                erg = erg / 12;
            }
            return erg;
        }

        public double Monatsumsatz(int monat)
        {
            double erg = 0;
            if (monat >= 0 && monat < numberOfMoths)
            {
                for (int verkauferidx = 0; verkauferidx < numberOfVerkaeufer; verkauferidx++)
                {
                    erg = erg + umsatz[verkauferidx, monat];
                }
            }
            erg /= numberOfVerkaeufer;

            return erg;
        }

        public double DurchschnittAllerVerkaeuferProJahr()
        {
            double erg = 0;
            for (int verkauferidx = 0; verkauferidx < numberOfVerkaeufer; verkauferidx ++)
            {
                for (int umsatzidx = 0; umsatzidx < numberOfMoths; umsatzidx++)
                {
                    erg = erg + umsatz[verkauferidx, umsatzidx];
                }

                erg = erg / 12;
            }

            return erg;
        }

        #endregion

    }
}
