﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Judth_Marcel_PLF01
{
    class matrix
    {
        #region eigenschaften
        int[,] matrix1;
        #endregion

        #region Konstruktor(en)
        public matrix ()
        {
            matrix1 = new int[0, 0];
        }
        #endregion

        #region Properties
        public int NumberOfCostumer
        {
            get { return matrix1.GetLength(0); }
            set
            {
                if(value > 0 && value < 100)
                {
                    matrix1 = new int[NumberOfCostumer, 12];
                }
            }
        }
        #endregion

        #region öffentliche-Methoden
        public int CompleteAverageYear()
        {
            int average = 0;
            int AnzahlZahlen = 0;

            for (int zeilenidx = 0; zeilenidx < NumberOfCostumer;zeilenidx++)
            {
                for(int spaltenidx = 0; spaltenidx < 12; spaltenidx++)
                {
                    average += matrix1[zeilenidx, spaltenidx];
                    AnzahlZahlen += 1;
                }
            }

            //average = average / AnzahlZahlen;
            return average;
        }
        public int CustomerAverageYear(int NumberCostumer)
        {
            int Average = 0;
          
            for(int spaltenidx = 0;spaltenidx < 12; spaltenidx++)
            {
                Average += matrix1[NumberCostumer, spaltenidx];
            }

            Average /= 12;
            return Average;
        }

        public int CompleteAverageMonth(int Month)
        {
            int Average = 0;

            for(int zeilenidx = 0; zeilenidx < NumberOfCostumer; zeilenidx++)
            {
                Average += matrix1[zeilenidx, Month];
            }

            //Average /= NumberOfCostumer;
            return Average;
        }
        public void savemoney()
        {
            int wert = 100;

            for (int zeilenidx = 0; zeilenidx < 12; zeilenidx++)
            {
                for (int spaltenidx = 0; spaltenidx < NumberOfCostumer; spaltenidx++)
                {
                    matrix1[zeilenidx, spaltenidx] = wert;
                    wert += 10;
                }
                wert -= 10;
            }
        }


        #endregion

    }
}
