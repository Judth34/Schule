﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Judth_Marcel_PLF01
{
    class Program
    {
        static void Main(string[] args)
        {
            matrix m1 = new matrix();
            int average1;
            int average2;

            m1.savemoney();

            average1 = m1.CompleteAverageMonth(1);
            average2 = m1.CompleteAverageYear();
            Console.WriteLine(average2);

        }
    }
}
