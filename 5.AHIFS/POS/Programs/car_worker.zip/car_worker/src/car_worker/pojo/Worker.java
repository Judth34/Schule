/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car_worker.pojo;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.concurrent.Task;

/**
 *
 * @author Julian
 */
public class Worker extends Task<String>{

    static final int MAX = 100;
    private StringProperty stringProperty = new SimpleStringProperty();
    
    @Override
    protected String call() throws Exception {
        for(int i=1; i<= MAX && !isCancelled(); i++){
            try{
                Thread.sleep(100);
            }catch(InterruptedException error){
                
            }
            String str = "--> " + i + " <--";
            Platform.runLater(()-> this.setStringProperty(str));
        }
        return "finsihed";
    }
    
    public void setStringProperty(String string) {
        this.stringProperty.set(string);
    }

    public static int getMAX() {
        return MAX;
    }

    public StringProperty getStringProperty() {
        return stringProperty;
    }
    
}
